#---------------------------- Edit This ------------------------------

#The location of where you want the filtered logs to go
FileLocation = 'C:/Users/frans/Documents/logFilterTool/filteredLogs/'

#The logs file name example: log.txt (has to be .txt)
logName = 'unfiltered.txt' 

#Name or id64 or chat message (can be left empty)
topic1 = 'dsod [dsod]:'

#Name or id64 or chat message (can be left empty)
topic2 = '/vault kappa'

#---------------------------- Edit This ------------------------------





#------------------------------------------------------------------------------
#------------------------- Program Start Do Not Touch -------------------------
#------------------------------------------------------------------------------
import time
date = time.strftime("%Y.%m.%d-%H.%M.%S")
log = []
with open(logName, 'rt', encoding='UTF-8') as f: 
    data = f.readlines()
for line in data:
    # String Containing the search string
    if topic1 in line and topic2 in line: 
        log.append(line)

for item in log:
    print(item)

with open(FileLocation + f"filteredlog{date}.txt", 'w',encoding='UTF-8') as g:
    for item in log:
        g.write(item)
        
print('File Successfully written wrong')
input()
#------------------------------------------------------------------------------
#------------------------- Program End Do Not Touch ---------------------------
#------------------------------------------------------------------------------
