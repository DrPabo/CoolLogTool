#---------------------------- Edit This ------------------------------
#This is where you want your filtered logs to be outputted
fileLocation = 'C:/Users/frans/Documents/logFilterTool/filteredLogs/'

#This is your "input data"
logName = 'unfiltered.txt' 
#---------------------------- Edit This ------------------------------



######################################################################################
##----------------------------------------------------------------------------------##
##----------------------------------------------------------------------------------##
##--------------------------- Program Start Do Not Touch ---------------------------##
##----------------------------------------------------------------------------------##
##----------------------------------------------------------------------------------##
######################################################################################
import time
date = time.strftime("%Y.%m.%d-%H.%M.%S")
playerList = []
toggleList = []
print("Awnser with 1 or empty")
isGlobal = input("Show Global Messages? : ")
if isGlobal:
    toggleList.append("[Info] [Main] [Global]")
isLocal = input("Show Local Messages? : ")
if isLocal:
    toggleList.append("[Info] [Main] [Local]")
isGroup = input("Show Group Messages? : ")
if isGroup:
    toggleList.append("[Info] [Main] [Group]")
isCommand = input("Show Command Messages? : ")
if isCommand:
    isReply = input("Show /R Messages? : ")
    if isReply:
        toggleList.append("/r")
        toggleList.append("/R")
    isPm = input("Show /PM Messages? : ")
    if isPm:
        toggleList.append("/pm")
        toggleList.append("/PM")
    isMsg = input("Show /MSG Messages? : ")
    if isMsg:
        toggleList.append("/msg")
        toggleList.append("/MSG")
isPlayer = input("Are we filtering players? : ")
if isPlayer:
    howManyPlayers = int(input("How Many Players: "))
    for i in range(howManyPlayers):
        playerList.append(str(input("Enter Player Name: ")))
tListLen = int(len(toggleList))
pListLen = int(len(playerList))
glgclog = []
log = []
with open(logName, 'rt', encoding='UTF-8') as f: 
    data = f.readlines()
for line in data:
    for x in range(tListLen):
        if toggleList[x] in line: 
            glgclog.append(line)
if isPlayer:
    for item in glgclog:
        for j in range(pListLen):
            if playerList[j] in item: 
                log.append(item)
    for item in log:
        print(item)
    with open(fileLocation + f"filteredlog{date}.txt", 'w', encoding='UTF-8') as g:
        for item in log:
            g.write(item)
else:
    for item in glgclog:
        print(item)
    with open(fileLocation + f"filteredlog{date}.txt", 'w', encoding='UTF-8') as g:
        for item in glgclog:
            g.write(item)    
print('File Successfully written wrong')
######################################################################################
##----------------------------------------------------------------------------------##
##----------------------------------------------------------------------------------##
##--------------------------- Program End Do Not Touch -----------------------------##
##----------------------------------------------------------------------------------##
##----------------------------------------------------------------------------------##
######################################################################################
